import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TestsRoutingModule } from './tests-routing.module';
import { AddComponent } from './add/add.component';
import { DefaultComponent } from './default/default.component';
import { EditComponent } from './edit/edit.component';

@NgModule({
  imports: [
    CommonModule,
    TestsRoutingModule
  ],
  declarations: [AddComponent, DefaultComponent, EditComponent]
})
export class TestsModule { }
